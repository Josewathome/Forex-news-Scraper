import asyncio
import logging
from playwright.async_api import async_playwright, Browser, BrowserContext, Page, Playwright

logger = logging.getLogger(__name__)

FF_URL  = "https://www.forexfactory.com/calendar"
MFB_URL = "https://www.myfxbook.com/forex-economic-calendar"
BG_URL  = "https://www.forexfactory.com/brokers/kenya"

STEALTH_SCRIPT = """
    Object.defineProperty(navigator, 'webdriver',  { get: () => undefined });
    Object.defineProperty(navigator, 'plugins',    { get: () => [1, 2, 3, 4, 5] });
    Object.defineProperty(navigator, 'languages',  { get: () => ['en-US', 'en'] });
    Object.defineProperty(navigator, 'maxTouchPoints', { get: () => 1 });
    window.chrome = { runtime: {} };
"""


class BrowserManager:
    """
    Owns the single Chromium instance and three persistent pages:
      ff_page  — ForexFactory calendar  (session cookie holder for API calls)
      mfb_page — MyFxBook economic calendar
      bg_page  — ForexFactory broker guide (broker spreads)
    """

    def __init__(self) -> None:
        self._playwright: Playwright     | None = None
        self._browser:    Browser        | None = None
        self._ctx:        BrowserContext | None = None

        self.ff_page:  Page | None = None
        self.mfb_page: Page | None = None
        self.bg_page:  Page | None = None

        self.ff_lock  = asyncio.Lock()
        self.mfb_lock = asyncio.Lock()
        self.bg_lock  = asyncio.Lock()

    # ------------------------------------------------------------------ #
    #  Lifecycle                                                           #
    # ------------------------------------------------------------------ #

    async def start(self) -> None:
        logger.info("Launching Chromium …")
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(
            headless=True,
            args=[
                "--no-sandbox",
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
                "--disable-infobars",
                "--disable-extensions",
                "--disable-gpu",
                "--window-size=1280,900",
            ],
        )
        self._ctx = await self._browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1280, "height": 900},
            java_script_enabled=True,
            ignore_https_errors=True,
            extra_http_headers={
                "Accept-Language": "en-US,en;q=0.9",
                "Accept": (
                    "text/html,application/xhtml+xml,"
                    "application/xml;q=0.9,image/webp,*/*;q=0.8"
                ),
            },
        )

        await self._ctx.add_init_script(STEALTH_SCRIPT)

        self.ff_page  = await self._ctx.new_page()
        self.mfb_page = await self._ctx.new_page()
        self.bg_page  = await self._ctx.new_page()

        await self._navigate_ff()
        await self._navigate_mfb()
        await self._navigate_bg()
        logger.info("All three pages loaded and ready.")

    async def stop(self) -> None:
        logger.info("Shutting down browser …")
        try:
            if self._browser:
                await self._browser.close()
            if self._playwright:
                await self._playwright.stop()
        except Exception as exc:
            logger.warning("Shutdown error: %s", exc)

    # ------------------------------------------------------------------ #
    #  Public reload methods                                               #
    # ------------------------------------------------------------------ #

    async def reload_ff(self) -> None:
        try:
            current_url = self.ff_page.url
            if not current_url or "forexfactory" not in current_url:
                logger.warning("FF page URL lost (%s), re-navigating …", current_url)
                await self._recover_ff()
            else:
                logger.debug("FF session page healthy at %s", current_url)
        except Exception as exc:
            logger.warning("FF page check failed (%s), recovering …", exc)
            await self._recover_ff()

    async def reload_mfb(self) -> None:
        try:
            await self._wait_for_mfb_ready(self.mfb_page)
        except Exception as exc:
            logger.warning("MFB page check failed (%s), recreating …", exc)
            await self._recover_mfb()

    async def reload_bg(self) -> None:
        # FIX: was checking for "myfxbook" but BG_URL is forexfactory.com
        try:
            current_url = self.bg_page.url
            if not current_url or "forexfactory" not in current_url:
                logger.warning("BG page URL lost (%s), re-navigating …", current_url)
                await self._recover_bg()
            else:
                logger.debug("BG session page healthy at %s", current_url)
        except Exception as exc:
            logger.warning("BG page check failed (%s), recovering …", exc)
            await self._recover_bg()

    # ------------------------------------------------------------------ #
    #  Internal navigation                                                 #
    # ------------------------------------------------------------------ #

    async def _navigate_ff(self) -> None:
        await self.ff_page.goto(FF_URL, wait_until="networkidle", timeout=60_000)
        await self._wait_for_ff_ready(self.ff_page)
        logger.debug("ForexFactory calendar page ready.")

    async def _navigate_mfb(self) -> None:
        await self.mfb_page.goto(MFB_URL, wait_until="domcontentloaded", timeout=60_000)
        await self._wait_for_mfb_ready(self.mfb_page)
        logger.debug("MyFxBook calendar page ready.")

    async def _navigate_bg(self) -> None:
        # Broker rows are rendered by JavaScript AFTER domcontentloaded fires.
        # At startup we only confirm the static page shell loaded.
        # The scraper calls page.goto() itself on every live request and waits
        # for "tbody.broker-guide__rows tr" after JS has fully rendered.
        await self.bg_page.goto(BG_URL, wait_until="domcontentloaded", timeout=60_000)
        await self._wait_for_bg_ready(self.bg_page)
        logger.debug("ForexFactory broker guide page ready.")

    # ------------------------------------------------------------------ #
    #  Wait-for-ready selectors                                            #
    # ------------------------------------------------------------------ #

    async def _wait_for_ff_ready(self, page: Page) -> None:
        await page.wait_for_selector("table.calendar__table", timeout=30_000)
        logger.debug("FF ready — table.calendar__table found")

    async def _wait_for_mfb_ready(self, page: Page) -> None:
        await page.wait_for_selector("#economicCalendarTable", timeout=30_000)
        logger.debug("MFB calendar ready — #economicCalendarTable found")

    async def _wait_for_bg_ready(self, page: Page) -> None:
        # FIX: original selector "tr.broker-guide__row, tr[data-broker],
        #      table.broker-guide" — none exist on the page.
        # FIX: "tbody.broker-guide__rows tr" times out at startup because the
        #      rows are JS-rendered after domcontentloaded.
        #
        # ".broker-guide" is a static wrapper div confirmed in debug section 2.
        # It is present in raw HTML immediately on load — safe to wait for here.
        #
        # The scraper does its own:
        #   await page.wait_for_selector("tbody.broker-guide__rows tr")
        # after its own page.goto(), by which time JS has rendered the rows.
        await page.wait_for_selector(".broker-guide", timeout=30_000)
        logger.debug("BG ready — .broker-guide shell found")

    # ------------------------------------------------------------------ #
    #  Recovery helpers                                                    #
    # ------------------------------------------------------------------ #

    async def _recover_ff(self) -> None:
        try:
            await self.ff_page.close()
        except Exception:
            pass
        self.ff_page = await self._ctx.new_page()
        await self._navigate_ff()

    async def _recover_mfb(self) -> None:
        try:
            await self.mfb_page.close()
        except Exception:
            pass
        self.mfb_page = await self._ctx.new_page()
        await self._navigate_mfb()

    async def _recover_bg(self) -> None:
        try:
            await self.bg_page.close()
        except Exception:
            pass
        self.bg_page = await self._ctx.new_page()
        await self._navigate_bg()