# scrapers/brokerguide.py
#
# FIX SUMMARY
# ───────────────────────────────────────────────────────────────────────────────
# The original JS looked for .slidetable__clone / .slidetable__original —
# neither exists on the page (confirmed by debug_brokerguide.py section 8 & 9).
#
# What the debug DID confirm:
#   • tbody.broker-guide__rows  →  contains all broker <tr>s  (sections 3 & 11)
#   • td.broker-guide__field--broker strong  →  broker display name  (section 6)
#   • td[data-column="eurusd"] etc.  →  spread cells, same <tr>  (section 5)
#   • .broker-guide__spread / --good / --bad  →  spread quality classes  (sec 2)
#
# All data (name + spreads) lives in the SAME <tr>.  No split clone/original.
# ───────────────────────────────────────────────────────────────────────────────

import asyncio
import logging
from datetime import datetime, timezone
from typing import List, Tuple

from playwright.async_api import Page, TimeoutError as PWTimeout

from models import BrokerSpreadEntry, BrokerSymbolSpread

logger = logging.getLogger(__name__)

BG_URL = "https://www.forexfactory.com/brokers/kenya"
MAX_RETRIES = 2

# Confirmed present from debug section 3 — all broker rows live here
_READY_SELECTOR = "tbody.broker-guide__rows tr"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _normalise_symbol(symbol: str) -> str:
    """'EUR/USD' → 'eurusd',  'EURUSD' → 'eurusd'"""
    return symbol.replace("/", "").replace("-", "").strip().lower()


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ── Public entry point ────────────────────────────────────────────────────────

async def scrape_broker_spreads(
    page: Page,
    brokers: List[str],
    symbols: List[str],
) -> Tuple[List[BrokerSpreadEntry], str]:
    """
    Returns (entries, scraped_at_iso).

    brokers — display names e.g. ["HFM", "IC Markets"]
              case-insensitive substring match against <strong> text confirmed
              working in debug section 6 (Strategy: any strong inside
              broker__field--broker).

    symbols — forex pairs e.g. ["EUR/USD", "USDJPY"]
              slash is optional — both forms resolve to the data-column key.
    """
    col_keys     = [_normalise_symbol(s) for s in symbols]
    broker_names = [b.strip() for b in brokers]

    logger.info("BG scrape | brokers=%s  col_keys=%s", broker_names, col_keys)

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            return await _load_and_parse(page, broker_names, symbols, col_keys)
        except PWTimeout as exc:
            logger.warning("BG timeout attempt %d/%d: %s", attempt, MAX_RETRIES, exc)
            if attempt == MAX_RETRIES:
                raise
            await asyncio.sleep(2)
        except Exception as exc:
            logger.error(
                "BG error attempt %d/%d: %s", attempt, MAX_RETRIES, exc, exc_info=True
            )
            if attempt == MAX_RETRIES:
                raise


# ── Core ──────────────────────────────────────────────────────────────────────

async def _load_and_parse(
    page: Page,
    broker_names: List[str],
    symbols: List[str],
    col_keys: List[str],
) -> Tuple[List[BrokerSpreadEntry], str]:

    logger.info("BG: navigating to %s …", BG_URL)
    await page.goto(BG_URL, wait_until="domcontentloaded", timeout=60_000)

    # Wait until at least one broker row is visible
    await page.wait_for_selector(_READY_SELECTOR, timeout=30_000)

    # Small extra wait — JS may still be populating spread values after DOM ready
    await asyncio.sleep(1.5)

    scraped_at = _now_iso()

    result = await page.evaluate(
        """
        (args) => {
            const { brokerNames, colKeys, symbols } = args;

            // ── 1. Collect every broker <tr> across ALL tbody.broker-guide__rows
            //        (debug confirmed 3 such tbodies — rows: 6, 4, 13)
            const allRows = [
                ...document.querySelectorAll(
                    'tbody.broker-guide__rows tr'
                )
            ];

            if (allRows.length === 0) {
                return {
                    error: 'No rows found — tbody.broker-guide__rows is empty',
                    entries: []
                };
            }

            // ── 2. Index broker name → row element
            //        Debug confirmed: td.broker-guide__field--broker strong
            //        holds the clean display name (e.g. "HFM", "IC Markets").
            const rowByName = new Map();   // lowercased name → tr element

            for (const tr of allRows) {
                const strong = tr.querySelector(
                    'td.broker-guide__field--broker strong'
                );
                if (!strong) continue;
                const name = strong.textContent.trim();
                if (name) rowByName.set(name.toLowerCase(), { name, tr });
            }

            if (rowByName.size === 0) {
                return {
                    error: 'Broker names not found — td.broker-guide__field--broker strong returned nothing',
                    entries: []
                };
            }

            // ── 3. Helper: extract spread data from a td[data-column="xxx"] cell
            //        Debug confirmed classes: .broker-guide__spread,
            //        .broker-guide__spread--good, .broker-guide__spread--bad
            function getCellData(tr, colKey) {
                const cell = tr.querySelector(`td[data-column="${colKey}"]`);
                if (!cell) return { spread: null, commission: null, quality: null };

                const spreadDiv = cell.querySelector('.broker-guide__spread');
                if (!spreadDiv) return { spread: null, commission: null, quality: null };

                // Spread value: first direct <span> child of the spread div
                const spanEl = spreadDiv.querySelector(':scope > span');
                const spread = spanEl ? spanEl.textContent.trim() || null : null;

                // Commission: optional sub-element; null when not present / empty
                const commEl = spreadDiv.querySelector('.commission, [class*="commission"]');
                const commission = commEl
                    ? (commEl.textContent.trim() || null)
                    : null;

                // Quality: --good means tighter than average, --bad means wider
                let quality = null;
                if (spreadDiv.classList.contains('broker-guide__spread--good')) quality = 'good';
                if (spreadDiv.classList.contains('broker-guide__spread--bad'))  quality = 'bad';

                return { spread, commission, quality };
            }

            // ── 4. Match each requested broker by case-insensitive substring
            const entries = [];

            for (const targetName of brokerNames) {
                const lower = targetName.toLowerCase();

                // Find first entry whose lowercased key contains the target substring
                let match = null;
                for (const [key, val] of rowByName) {
                    if (key.includes(lower)) { match = val; break; }
                }

                if (!match) {
                    // Return the entry as "not found" with null spreads
                    entries.push({
                        broker: targetName,
                        found:  false,
                        symbol_data: colKeys.map((_, i) => ({
                            symbol: symbols[i],
                            spread: null, commission: null, quality: null,
                        })),
                    });
                    continue;
                }

                const symbol_data = colKeys.map((colKey, i) => ({
                    symbol: symbols[i],
                    ...getCellData(match.tr, colKey),
                }));

                entries.push({
                    broker: match.name,
                    found:  true,
                    symbol_data,
                });
            }

            return { error: null, entries };
        }
        """,
        {"brokerNames": broker_names, "colKeys": col_keys, "symbols": symbols},
    )

    if result.get("error"):
        raise RuntimeError(f"BG JS extraction failed: {result['error']}")

    raw_entries = result.get("entries", [])
    logger.info(
        "BG: %d broker(s) extracted | symbols=%s | at %s",
        len(raw_entries), symbols, scraped_at,
    )

    entries: List[BrokerSpreadEntry] = []
    for raw in raw_entries:
        if not raw.get("found"):
            logger.warning(
                "BG: broker %r not found on page — all spreads will be null",
                raw["broker"],
            )

        symbol_spreads = [
            BrokerSymbolSpread(
                symbol     = sd["symbol"],
                spread     = sd.get("spread"),
                commission = sd.get("commission"),
                quality    = sd.get("quality"),
            )
            for sd in raw.get("symbol_data", [])
        ]
        entries.append(
            BrokerSpreadEntry(
                broker     = raw["broker"],
                symbols    = symbol_spreads,
                scraped_at = scraped_at,
            )
        )

    return entries, scraped_at


# ── Convenience: scrape every broker on the page ─────────────────────────────

async def scrape_all_brokers(
    page: Page,
    symbols: List[str],
) -> Tuple[List[BrokerSpreadEntry], str]:
    """
    Scrape spread data for ALL brokers listed on the page.
    Internally discovers broker names from the DOM, then delegates to
    _load_and_parse so the same extraction logic is reused.
    """
    col_keys = [_normalise_symbol(s) for s in symbols]

    logger.info("BG scrape_all_brokers | col_keys=%s", col_keys)

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            # Step 1: navigate once and collect all broker display names
            logger.info("BG /all: navigating to %s …", BG_URL)
            await page.goto(BG_URL, wait_until="domcontentloaded", timeout=60_000)
            await page.wait_for_selector(_READY_SELECTOR, timeout=30_000)
            await asyncio.sleep(1.5)

            # Grab every broker name via the confirmed selector
            broker_names: List[str] = await page.evaluate(
                """
                () => {
                    const strongs = document.querySelectorAll(
                        'tbody.broker-guide__rows tr td.broker-guide__field--broker strong'
                    );
                    return [...strongs]
                        .map(s => s.textContent.trim())
                        .filter(Boolean);
                }
                """
            )

            if not broker_names:
                raise RuntimeError(
                    "scrape_all_brokers: no broker names found on page"
                )

            logger.info("BG /all: discovered %d brokers", len(broker_names))

            # Step 2: reuse the same parse path (page already loaded)
            scraped_at = _now_iso()
            result = await page.evaluate(
                """
                (args) => {
                    const { brokerNames, colKeys, symbols } = args;

                    const allRows = [
                        ...document.querySelectorAll('tbody.broker-guide__rows tr')
                    ];

                    function getCellData(tr, colKey) {
                        const cell = tr.querySelector(`td[data-column="${colKey}"]`);
                        if (!cell) return { spread: null, commission: null, quality: null };
                        const spreadDiv = cell.querySelector('.broker-guide__spread');
                        if (!spreadDiv) return { spread: null, commission: null, quality: null };
                        const spanEl = spreadDiv.querySelector(':scope > span');
                        const spread = spanEl ? spanEl.textContent.trim() || null : null;
                        const commEl = spreadDiv.querySelector('.commission, [class*="commission"]');
                        const commission = commEl ? (commEl.textContent.trim() || null) : null;
                        let quality = null;
                        if (spreadDiv.classList.contains('broker-guide__spread--good')) quality = 'good';
                        if (spreadDiv.classList.contains('broker-guide__spread--bad'))  quality = 'bad';
                        return { spread, commission, quality };
                    }

                    const entries = [];
                    for (const tr of allRows) {
                        const strong = tr.querySelector(
                            'td.broker-guide__field--broker strong'
                        );
                        if (!strong) continue;
                        const name = strong.textContent.trim();
                        if (!name) continue;

                        const symbol_data = colKeys.map((colKey, i) => ({
                            symbol: symbols[i],
                            ...getCellData(tr, colKey),
                        }));
                        entries.push({ broker: name, found: true, symbol_data });
                    }
                    return { error: null, entries };
                }
                """,
                {"brokerNames": broker_names, "colKeys": col_keys, "symbols": symbols},
            )

            if result.get("error"):
                raise RuntimeError(f"BG /all JS failed: {result['error']}")

            entries: List[BrokerSpreadEntry] = []
            for raw in result.get("entries", []):
                symbol_spreads = [
                    BrokerSymbolSpread(
                        symbol     = sd["symbol"],
                        spread     = sd.get("spread"),
                        commission = sd.get("commission"),
                        quality    = sd.get("quality"),
                    )
                    for sd in raw.get("symbol_data", [])
                ]
                entries.append(
                    BrokerSpreadEntry(
                        broker     = raw["broker"],
                        symbols    = symbol_spreads,
                        scraped_at = scraped_at,
                    )
                )

            logger.info(
                "BG /all: %d broker(s) extracted at %s", len(entries), scraped_at
            )
            return entries, scraped_at

        except PWTimeout as exc:
            logger.warning(
                "BG /all timeout attempt %d/%d: %s", attempt, MAX_RETRIES, exc
            )
            if attempt == MAX_RETRIES:
                raise
            await asyncio.sleep(2)
        except Exception as exc:
            logger.error(
                "BG /all error attempt %d/%d: %s", attempt, MAX_RETRIES, exc,
                exc_info=True,
            )
            if attempt == MAX_RETRIES:
                raise